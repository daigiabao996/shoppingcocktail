import React from 'react'
import Helpers from '../../utils/Helpers';
import './ProductDetail.css'

export default function ProductDetail() {
    let product = localStorage.getItem('item')
    product = JSON.parse(product);

    return (
        <>
            <div className="product-item">
                <div className="product-item__image col-4">
                    <img src={product.strDrinkThumb} alt="" />
                </div>
                <div className="product-item__content col-8">
                    <div>Name: <span>{product.strDrink}</span></div>
                    <div>Type: <span>{product.strAlcoholic}</span></div>
                    <div>Instructions: <span>{product.strInstructions}</span></div>
                </div>
                <div className="products-item__button">
                    <button type="button" onClick={() => Helpers.handleAddToCart(product)}>ADD TO CART</button>
                </div>
            </div>
        </>
    )
}
